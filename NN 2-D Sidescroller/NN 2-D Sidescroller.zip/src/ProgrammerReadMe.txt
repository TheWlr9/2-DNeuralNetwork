You can alter MUT_RATE and CROSS_RATE in the Controller class to change the frequency of mutations and crossovers in the genetic algorithm. View the GeneticAlgorithm class to see how those values affect the program.

The newMarioGame(File levelFile) is currently incomplete. I will eventually implement a level editor dependant on user input or from a file that the user can alter.