package marioGame;

import java.io.*;

final class Level {
	Level(File levelFile){
		
	}
}
